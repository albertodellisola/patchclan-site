Yuu Yuu Hakusho Gaiden (幽☆遊☆白書・外伝)
English Translation v1.0.1 - Patch Clan
Released: November 4, 2026
Platform: Mega Drive

------------------------------------------------------------------------
ABOUT THE GAME
------------------------------------------------------------------------
Yuu Yuu Hakusho Gaiden is an adventure game with fighting-game battles,
published by Sega for the Mega Drive in Japan on January 28, 1994, and
developed by Gau Entertainment. It was never released outside Japan.

------------------------------------------------------------------------
WHAT THE PATCH DOES
------------------------------------------------------------------------
- Translates the whole game into English: all 1,531 lines of the script,
  including the menus, the options screen, and the save and load
  screens, plus the hero names in the battle status box and all 36 enemy names.
- Redraws the graphics with Japanese text: the title logo, the large logo
  before the final chapter, the name captions in the title demo, the
  station sign, the fortune teller's sign, the cram-school building and
  its signs, and the closing THE END graphic.
- Fixes two problems from the original cartridge:
    * The arrow at the end of each text box and the menu cursor flashed
      15 times per second. They now flash about four times per second.
    * Kuwabara's Spirit Sword no longer flickers. In the original, the
      sword sprites switched off on every other frame for almost two
      seconds.

The patch adds no new options, and battle balance is unchanged. A Patch
Clan screen showing the patch version appears for about five seconds at
startup, and pressing A or START skips it.

------------------------------------------------------------------------
HOW TO APPLY
------------------------------------------------------------------------
Apply the IPS patch to a clean, unmodified copy of the Japanese ROM,
using Floating IPS, Lunar IPS or any IPS patcher.

Original ROM: Yuu Yuu Hakusho Gaiden (Japan).md
  Size:     2,097,152 bytes (no header)
  CRC32:    7DC98176
  MD5:      A339561A0D46FEE4C2569DE0B237A02B
  SHA-1:    274B86709B509852CA004CEAA244F3AE1D455C50

Patched ROM:
  Size:     4,194,304 bytes
  CRC32:    1814ACE6
  MD5:      E47BB7394E5672A6EACB202098DFCEE0

------------------------------------------------------------------------
SAVING AND COMPATIBILITY
------------------------------------------------------------------------
Because the ROM is now larger than 2 MB, the patch uses the $A130F1
register to switch in the save memory only while the game reads or
writes it. An emulator or flash cartridge must support that register
for saving to work.

------------------------------------------------------------------------
KNOWN ISSUES
------------------------------------------------------------------------
- Saving and loading were tested in MAME. An earlier build of this
  version ran on an EverDrive, but saving has not been confirmed on real
  hardware.
- The small caption GENKAI in the title demo uses a very narrow font, so
  its N is hard to tell from an H.

------------------------------------------------------------------------
CREDITS
------------------------------------------------------------------------
Translation and fixes: Patch Clan.
Original game: Sega and Gau Entertainment.

This archive contains only the patch. It does not contain the game.
