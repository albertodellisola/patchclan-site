Captain Tsubasa (キャプテン翼)
English Translation v1.2.0 - Patch Clan
Released: November 8, 2026
Platform: Famicom (NES)

------------------------------------------------------------------------
ABOUT THE GAME
------------------------------------------------------------------------
Captain Tsubasa is a soccer game played through menus, released by
Tecmo for the Famicom in Japan on April 28, 1988. Every pass, dribble
and shot is chosen from a menu, and each move spends Guts, the players'
stamina. In 1992 the game came to North America and Europe as Tecmo Cup
Soccer Game, with almost the whole cast replaced by new characters.

------------------------------------------------------------------------
WHAT THE PATCH DOES
------------------------------------------------------------------------
- Translates the whole game into English, keeping the original Japanese
  cast: match commentary, cutscenes, classroom scenes, the search for
  Misaki in Paris, the coach's menu, player cards and the ending.
- Doubles the space in the commentary boxes (14 to 28 characters in the
  match windows, 18 to 36 in the larger ones) and adds a new English
  font of 74 tiles.
- Redraws the title logo and the small classroom logo in English, and
  puts Latin letters and digits on the password screen.
- Fixes three problems in the original cartridge:
    * The ball no longer loses its right half when it moves on the
      pitch.
    * The score stops at 255 goals instead of rolling over to 0.
    * Passwords that pointed past the end of the team list showed a
      garbled opponent name, and one froze the game. They now lead to
      a valid opponent.
- Adds a battery save with five slots. SAVE in the coach's menu saves
  the progress, and CONTINUE on the title screen loads it. Holding B
  while choosing CONTINUE still opens the password screen.

A Patch Clan screen showing the patch version appears at startup.

------------------------------------------------------------------------
HOW TO APPLY
------------------------------------------------------------------------
Apply the IPS patch to a clean, unmodified copy of the Japanese ROM,
using Floating IPS, Lunar IPS or any IPS patcher.

Original ROM: Captain Tsubasa (Japan).nes
  Size:     262,160 bytes (with 16-byte iNES header)
  CRC32:    0F68ED1B
  MD5:      EEB77E6E0E0B5695F9A35F47979C4722
  SHA-1:    BA366FEFE13A3746510ACAB2FE73D4DB1FD8DCE4
  Without header: CRC32 F3F1269D

Patched ROM:
  Size:     393,232 bytes (MMC1, battery-backed save)
  CRC32:    39B9FDD0
  MD5:      AA0BC053572DB8BBA3EF9B481EE2684C

------------------------------------------------------------------------
SAVING AND COMPATIBILITY
------------------------------------------------------------------------
The game was played through in Mesen. Saving was tested by closing the
emulator and reopening it with the save file the game had written. It
has not been tested on real hardware or a flash cartridge.

------------------------------------------------------------------------
KNOWN ISSUES
------------------------------------------------------------------------
- When Ozora's dialogue box opens at half-time, its border is drawn
  incomplete for a single frame (1/60 of a second). A fix is planned
  for the next version.
- The cursor underline in the player list flickers, as it does on the
  original cartridge.
- If the player holds Up while an opponent dribbles, the opponent seems
  to walk backwards. This comes from the original game and was left
  unchanged.

------------------------------------------------------------------------
CREDITS
------------------------------------------------------------------------
Translation, fixes and improvements: Patch Clan.
Original game: Tecmo.

This archive contains only the patch. It does not contain the game.
