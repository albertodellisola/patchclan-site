Maniac Mansion (マニアックマンション)
English Translation v1.2 - Patch Clan
Released: October 24, 2026
Platform: Famicom (Nintendo Family Computer)

------------------------------------------------------------------------
ABOUT THE GAME
------------------------------------------------------------------------
Maniac Mansion is Jaleco's Famicom conversion of the Lucasfilm Games
adventure, released in Japan on September 13, 1988. It is a different
game from the 1990 NES version, with its own engine, redrawn art and
rooms that do not scroll. This Famicom version was never released in
English.

------------------------------------------------------------------------
WHAT THE PATCH DOES
------------------------------------------------------------------------
- Translates the whole game into English: dialogue, object descriptions,
  inventory and room names (814 text entries), the team screen with the
  biographies of all seven kids, the intro caption, the password
  screens, the epilogue, the secret passwords and the 65 hidden
  developer messages.
- Redraws the title screen and the screens with Japanese text in the
  artwork.
- Fixes three problems from the original cartridge:
    * When all three kids die, the game goes to the GAME OVER screen.
      In the original, it stayed on the gravestones until RESET was
      pressed.
    * Non-player characters accept only the items that make sense for
      them. In the original, an essential item could be given away and
      lost for good.
    * A stray red symbol no longer appears on the password screens.
- Adds battery saving. SELECT shows the password and also saves, and
  CONTINUE on the team screen resumes from the last save. There is one
  save slot, and each new save overwrites it. Passwords still work.
- Puts the twelve commands in a new order, so OPEN and CLOSE, PUSH and
  PULL, and TURN ON and TURN OFF sit one above the other.
- Makes TURN ON and TURN OFF also open and close the faucets and the
  pool valve.

------------------------------------------------------------------------
HOW TO APPLY
------------------------------------------------------------------------
Apply the IPS patch to a clean, unmodified copy of the Japanese ROM WITH
its 16-byte header, using Floating IPS, Lunar IPS or any IPS patcher.

Original ROM: Maniac Mansion (Japan).nes
  Size with header:      262,160 bytes
  CRC32 with header:     6571F742
  MD5 with header:       5835600ABB0A8DE98D905DA545350160
  SHA-1 with header:     D5E63DF09043F4BDD810CFE1EB99BF3B368826BF
  CRC32 without header:  3DA2085E
  SHA-1 without header:  0F90852C9BB9C47419153A262A23E83DF314DF5C

Patched ROM:
  Size:   524,304 bytes
  CRC32:  BBEF9804
  MD5:    F12819C03888C1B39B1F6F22DD223806

The patch rewrites the header as NES 2.0, so an original ROM with an
older iNES header gives the same patched ROM.

------------------------------------------------------------------------
SAVING AND COMPATIBILITY
------------------------------------------------------------------------
The patched game uses an MMC1 board (SUROM) with 512 KB of program
memory and 8 KB of battery-backed memory. Use an emulator that supports
this board and keeps battery saves. A reproduction cartridge needs a
SUROM board with a battery. The patched game does not fit the original
board. The password is intentionally still written in Japanese symbols
and the letters A to T.

------------------------------------------------------------------------
KNOWN ISSUES
------------------------------------------------------------------------
- Saving was tested in Mesen. It has not been tested on real hardware,
  including flash cartridges.

------------------------------------------------------------------------
CREDITS
------------------------------------------------------------------------
Translation, fixes and improvements: Patch Clan.
Original game: Lucasfilm Games and Jaleco.

This archive contains only the patch. It does not contain the game.
