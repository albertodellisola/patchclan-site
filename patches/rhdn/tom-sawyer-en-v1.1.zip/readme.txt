Square's Tom Sawyer - English Translation
Version 1.1 (November 22, 2026)
By Patch Clan and BlackPaladin

THE GAME
Square's Tom Sawyer (Square no Tom Sawyer) is a role-playing game by Square, released only in Japan for the
Famicom on November 30, 1989. It is loosely based on Mark Twain's novel The Adventures of Tom Sawyer.

WHAT THIS PATCH DOES
- Translates the whole game into English: dialogue, item and enemy names, battle messages, menus, the
  name-entry keyboard, the rock-paper-scissors calls, the staff's closing message and the hidden messages.
- Redraws the title screen as SQUARE'S TOM SAWYER.
- Expands the ROM from 256 KB to 512 KB (SUROM) to fit the English text. Battery saving works as before.
- Includes the Jim Design Fix by Yoni Arousement (portraits by Pixeltomia, palette research by Bavi_H),
  which replaces the original blackface caricature of Jim. Only his graphics change.
- Adds a Patch Clan screen with the credits and the patch version before the title screen.

NEW IN VERSION 1.1
- Eleven enemy names that were still in Japanese in the battle messages (among them the twins, Alfred,
  Mister X and Henry) are now in English.

HOW TO APPLY
Apply tom-sawyer-en-v1.1.ips to a clean copy of the ROM below with an IPS patcher such as Lunar IPS or
Floating IPS. Keep the 16-byte header.

Required ROM: Square no Tom Sawyer (Japan).nes
  Size:   262160 bytes (with header)
  CRC32:  8492EC99
  MD5:    B7E85EC90D071443EA69614C02A7A0A0
  SHA-1:  836EEC5F90F2E4E33794102FEDA90A609D74336A
  Without header: CRC32 CB0A76B1, SHA-1 FF166FCAD80C61A17641A7C029DD2EB3D99495FD

Patched ROM:
  Size:   524304 bytes (with header)
  CRC32:  FEF9EE66
  MD5:    B6669B7E7A1097741F0033F597B97100

KNOWN ISSUES
- Bugs present in the original cartridge were left unchanged. The TENT and the LAMP must never be given away:
  without the TENT the game cannot be saved, and without the LAMP it cannot be finished. Holding a ninth TILE
  freezes the game.
- The game was played from start to finish in the Mesen emulator. It was not tested on real hardware or
  flash cartridges.
- A reproduction cartridge needs an SUROM board with a battery; the patched game does not fit the original board.

CREDITS
English translation: Patch Clan and BlackPaladin.
Jim Design Fix: Yoni Arousement, Pixeltomia and Bavi_H.
Original game: (C) 1989 Square.

This archive contains only the patch. It does not contain the game ROM.
