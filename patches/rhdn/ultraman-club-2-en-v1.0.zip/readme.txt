Ultraman Club 2: Kaettekita Ultraman Club (The Return of Ultraman Club)
English Translation v1.0 - Patch Clan
Released: October 23, 2026
Platform: Famicom (Nintendo Family Computer)

------------------------------------------------------------------------
ABOUT THE GAME
------------------------------------------------------------------------
Ultraman Club 2: Kaettekita Ultraman Club is an RPG released only in
Japan for the Famicom on April 7, 1990, published by Yutaka with Bandai
and developed by Interlink. It was the debut of Kenji Eno, credited as
planner, who later created D. The hero, MAN, travels from Earth to the
Moon, Planet Dokkun, the Monster Graveyard and Planet Ultra, joined by
Seven, Jack, Ace and Taro.

------------------------------------------------------------------------
WHAT THE PATCH DOES
------------------------------------------------------------------------
- Translates the whole game into English: 653 text entries (447
  messages, 56 menu, move and item entries, 146 battle entries and four
  Japanese particles written directly into the battle code).
- Fixes mistakes from the original cartridge: Seagorath and Seamons
  had each other's names, eight monster names were misspelled, Alien
  Babarue and Alien Magma had each other's sprites, and Tyrant's arms
  were drawn on the wrong sides.
- Gives six bosses their own map sprite and recolors eight monsters to
  match the TV series.
- Adds an OPTIONS menu on the title screen with ten settings. Each one
  can be set back to the original behavior:
    AUTO SAVE        saves whenever the game displays the Ultra Sign
                     password; CONTINUE on the title resumes from there
    QUICK TEXT       faster battle messages
    ALWAYS RUN       the party runs on the map without holding B
    ENCOUNTERS       HALF or NORMAL random battle rate
    WEAK FOES        NORMAL, HALF or NONE battles against groups far
                     below the party's level
    KEEP EXP         EXP is kept after a game over
    DOUBLE EXP       twice the EXP until Ace joins the party
    RUIN RAY GUARD   the Ruin Ray can no longer knock MAN out in one hit
    ALLY TAKEOVER    the battle goes on if MAN falls while an ally stands
    HIDE USELESS KO  instant-kill moves are hidden against immune bosses
- Always on: the capsule list on the map describes each capsule, and
  the Woo capsule is no longer wasted when nobody is knocked out.

------------------------------------------------------------------------
HOW TO APPLY
------------------------------------------------------------------------
Apply the IPS patch to a clean, unmodified copy of the Japanese ROM
WITH its 16-byte iNES header (Floating IPS, Lunar IPS or any online
IPS patcher). Do not apply it over the earlier alpha or beta patch.

  Ultraman Club 2 - Kaettekita Ultraman Club (Japan).nes
  Size:    262,160 bytes (with header)
  CRC32:   C23926CD
  MD5:     1E479BFE8E4D3C36DE37DFB96AA8E68C
  SHA-1:   B031678EC59993E12F84E42E9244E8AB5CE26B4D

  Patched ROM: 524,304 bytes, CRC32 78BF2BF9

The patch converts the header to NES 2.0 and declares battery-backed
memory, used by AUTO SAVE. Saving was tested in Mesen. The Ultra Sign
password still works, and its kana symbols remain as in the original
because they make up the password.

------------------------------------------------------------------------
KNOWN ISSUES (planned for v1.1)
------------------------------------------------------------------------
- With ALWAYS RUN on, the party also runs inside towns and castles, and
  one floor tile in the Moon castle can flicker.
- In the capsule list on the map, the help line appears directly under
  the Ultra's name, and the two can read as one sentence.

------------------------------------------------------------------------
CREDITS
------------------------------------------------------------------------
Translation, fixes and improvements: Patch Clan
Project page: www.patchclan.com

This is a patch only. No ROM is included or distributed.
